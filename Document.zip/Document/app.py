import os
from flask import Flask, request, render_template
import PyPDF2
import docx
from PIL import Image
import pytesseract
import requests
import json

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads/'
app.config['ALLOWED_EXTENSIONS'] = {'txt', 'pdf', 'docx', 'jpg', 'jpeg', 'png'}

# Create the uploads folder if it doesn't exist
if not os.path.exists(app.config['UPLOAD_FOLDER']):
    os.makedirs(app.config['UPLOAD_FOLDER'])

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

def extract_text_from_file(filepath):
    ext = filepath.rsplit('.', 1)[1].lower()
    text = ""

    if ext == 'pdf':
        with open(filepath, 'rb') as file:
            reader = PyPDF2.PdfReader(file)
            for page in reader.pages:
                text += page.extract_text() or ""
    elif ext == 'docx':
        doc = docx.Document(filepath)
        for paragraph in doc.paragraphs:
            text += paragraph.text + "\n"
    elif ext in {'jpg', 'jpeg', 'png'}:
        image = Image.open(filepath)
        text = pytesseract.image_to_string(image)
    elif ext == 'txt':
        with open(filepath, 'r') as file:
            text = file.read()
    
    return text

def summarize_text(text, api_key):
    url = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash-latest:generateContent'
    headers = {'Content-Type': 'application/json'}
    data = {
        "contents": [
            {
                "parts": [
                    {"text": text}
                ]
            }
        ]
    }
    response = requests.post(url, headers=headers, params={'key': api_key}, data=json.dumps(data))
    if response.status_code == 200:
        return response.json()  # Return the entire JSON response
    else:
        return {"error": "Unable to summarize text"}

@app.route('/', methods=['GET', 'POST'])
def upload_file():
    if request.method == 'POST':
        if 'file' not in request.files:
            return 'No file part'
        file = request.files['file']
        if file.filename == '':
            return 'No selected file'
        if file and allowed_file(file.filename):
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
            file.save(filepath)

            # Extract text from the uploaded file
            extracted_text = extract_text_from_file(filepath)
            
            # Call the Gemini API to summarize the extracted text
            api_key = 'AIzaSyCES7de-0K68QakhYLPK1TNRrwhHlc8wJ4'  # Replace with your actual API key
            summary = summarize_text(extracted_text, api_key)

            return render_template('result.html', summary=summary)
    return render_template('upload.html')

if __name__ == '__main__':
    app.run(debug=True)
